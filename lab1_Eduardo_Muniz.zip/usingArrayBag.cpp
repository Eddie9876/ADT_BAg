/****************************************************************/
/* Program:      Bag Games
/* Name:         Eduardo Muniz 
/* Lab:          Lab 1
/* Description:  This program uses two bags of integers. Each bag
/*               gets 10 random numbers from 1 to 10 (repeats are
/*               ok). There is a menu with 4 choices:
/*                    Play Most Dups - two players each get a bag
/*                    and whoever has the number that shows up the
/*                    most times wins
/*                    Find Products - shows the product of the
/*                    numbers in each bag (uses the recursive
/*                    getProduct method in ArrayBag)
/*                    Load New Values - empties both bags and
/*                    puts in new random numbers
/*                    Quit
/*               The menu keeps showing up until the user quits.
/****************************************************************/

#include <iostream>
#include <string>
#include <cstdlib>     // for rand and srand
#include <ctime>       // for time
#include <random>
#include "ArrayBag.h"

using namespace std;

// prototypes
void loadBag(ArrayBag<int>& bag);
void displayBag(ArrayBag<int>& bag, string label);
void displayMenu();
int getMenuChoice();
void choiceOne(const ArrayBag<int>& bag1, const ArrayBag<int>& bag2);
void choiceTwo(ArrayBag<int>& bag1, ArrayBag<int>& bag2);

int main()
{
	// make the two bags, one for each player
	ArrayBag <int> bag1;
	ArrayBag <int> bag2;

	// only seed once at the start so the numbers are different each run
	srand(time(0));

	// put 10 random numbers in each bag
	loadBag(bag1);
	loadBag(bag2);
	
	// keep showing the menu until they pick 4
	int choice = 0;
	while (choice != 4) 
	{
		displayMenu();               // print the options
		choice = getMenuChoice();    // get a choice that is 1-4

		if (choice == 1)
		{
			// most dups game
			choiceOne(bag1, bag2);
		}
		else if (choice == 2)
		{
			// products
			choiceTwo(bag1, bag2);
		}
		else if (choice == 3)
		{
			// empty the bags then fill them again
			bag1.clear();
			bag2.clear();
			loadBag(bag1);
			loadBag(bag2);
			cout << endl;
			cout << "New values are loaded." << endl;
			displayBag(bag1, "Bag 1");
			cout << endl;
			displayBag(bag2, "Bag 2");
			cout << endl;
		}
		// if they pick 4 nothing happens here, the while loop just ends
	}
	return 0;
} 

/****************************************************************/
/* Function:   loadBag
/* Inputs:     bag - the bag to fill (uses & so it changes the
/*             real bag and not a copy)
/* Outputs:    nothing, but the bag has 10 new numbers in it
/* Purpose:    adds 10 random numbers from 1 to 10 to the bag
/****************************************************************/
void loadBag(ArrayBag<int>& bag)
{
	for (int c = 0; c < 10; c++) 
	{
		// rand() % 10 is 0-9 so adding 1 makes it 1-10
		bag.add(rand() % 10 + 1);
	}
}

/****************************************************************/
/* Function:   displayBag
/* Inputs:     bag - the bag to print
/*             label - what to print before the numbers (like Bag 1)
/* Outputs:    nothing, just prints to the screen
/* Purpose:    prints everything in the bag on one line
/****************************************************************/
void displayBag(ArrayBag<int>& bag, string label)
{
	// toVector gives me a copy of the bag's numbers that I can loop through
	vector<int> contents = bag.toVector();
	cout << label << ": ";

	// print each number with a space after it
	for (int i = 0; i < contents.size(); i++)
	{
		cout << contents[i] << " ";
	}
	cout << endl;
}

/****************************************************************/
/* Function:   displayMenu
/* Inputs:     none
/* Outputs:    nothing, just prints to the screen
/* Purpose:    prints the menu options
/****************************************************************/
void displayMenu()
{
		cout << "1. Play most dups\n";
		cout << "2. Find products\n";
		cout << "3. Load new values\n";
		cout << "4. Quit\n";
}

/****************************************************************/
/* Function:   getMenuChoice
/* Inputs:     none (reads what the user types)
/* Outputs:    returns the choice, which will always be 1-4
/* Purpose:    keeps asking until the user types a whole number
/*             from 1 to 4
/****************************************************************/
int getMenuChoice()
{
	int choice = 0;
	bool valid = false;

	// keep asking until the choice is good
	while (!valid)
	{
		cout << "Enter Your choice (1-4): ";
		cin >> choice;
		if (cin.fail())
		{
			// they typed something that isn't a number like a letter
			cin.clear();              // fixes cin so it works again
			cin.ignore(1000, '\n');   // gets rid of the bad stuff they typed
			cout << "Please enter a number\n";
			
		}
		else 
		{
			// it was a number, so get rid of the leftover enter key
			// (if I don't, getline later reads an empty line)
			cin.ignore(1000, '\n');

			// make sure the number is between 1 and 4
			if (choice < 1 || choice > 4 )
				cout << "Choice must be between 1 and 4.\n";
			else
				valid = true;
		}
	}
	return choice;
}

/****************************************************************/
/* Function:   choiceOne (Play Most Dups)
/* Inputs:     bag1 - player 1's bag
/*             bag2 - player 2's bag
/*             (const because this function only looks at the bags)
/* Outputs:    nothing, just prints to the screen
/* Purpose:    plays the game. Asks for both names, finds the
/*             number that shows up the most in each bag, and says
/*             who won (or if it is a tie)
/****************************************************************/
void choiceOne(const ArrayBag<int>& bag1, const ArrayBag<int>& bag2) 
{
	string playerName1;
	string playerName2;

	// use getline since names can have spaces
	cout << "Who is player 1: ";
	cout << endl;
	getline(cin, playerName1);
	cout << "Who is player 2: ";
	cout << endl;
	getline(cin, playerName2);

	// these keep track of the best number so far for each bag
	// count = how many times it showed up, value = the number itself
	int mostCount1 = 0;
	int mostValue1 = 0;
	int mostCount2 = 0;
	int mostValue2 = 0;

	// go through every number the bags could have (1-10)
	for (int value = 1; value <= 10; value++)
	{
		// how many times is this number in each bag
		int count1 = bag1.getFrequencyOf(value);
		int count2 = bag2.getFrequencyOf(value);

		// if it showed up more than the best so far in bag 1, save it
		if (count1 > mostCount1) {
			mostCount1 = count1;
			mostValue1 = value;
		}

		// same thing for bag 2
		if (count2 > mostCount2) {
			mostCount2 = count2;
			mostValue2 = value;
		}

	}

	// print each player's most common number and how many times it showed up
	cout << playerName1 << "'s most frequent value is " << mostValue1 << " with count " << mostCount1 << endl;
	cout << playerName2 << "'s most frequent value is " << mostValue2 << " with count " << mostCount2 << endl;

	// whoever has the bigger count wins
	// if the counts are the same I just say it's a tie
	if (mostCount1 > mostCount2)
	{
		cout << playerName1 << " wins!" << endl << "they have " << mostCount1 << " " << mostValue1 << "'s" << endl;
	}
	else if (mostCount2 > mostCount1)
	{
		cout << playerName2 << " wins!" << endl << "they have " << mostCount2 << " " << mostValue2 << "'s" << endl;
	}
	else if (mostCount1 == mostCount2)
	{
		cout << "It's a tie!" << endl;
	}

}

/****************************************************************/
/* Function:   choiceTwo (Find Products)
/* Inputs:     bag1 - the first bag
/*             bag2 - the second bag
/* Outputs:    nothing, just prints to the screen
/* Purpose:    prints the product of all the numbers in each bag
/*             using the recursive getProduct method
/****************************************************************/
void choiceTwo(ArrayBag<int>& bag1, ArrayBag<int>& bag2) 
{

	displayBag(bag1, "Bag 1 ");
	displayBag(bag2, "Bag 2 ");
	// getProduct multiplies all the numbers in the bag together
	cout << "Result: " << bag1.getProduct() << endl;

	cout << "Result: " << bag2.getProduct() << endl;

	cout << endl;
}
